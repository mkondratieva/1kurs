#include <stdio.h>
#include <stdlib.h>
//#include "walloc.h"
int main(int argc,const char **argv)
{char *p1,*p2,*p3; float a=1.f;
argc=argc;argv=argv;
 p1=(char*)malloc(10);
 p2=(char*)malloc(20);
 p3=(char*)malloc(30);
 free(p1);
// free(p2);
// WCheckMemCleaningShow();
 p1=(char*)malloc(30);
// WCheckMemCleaningShow();
 free(p1);
// free(p2);
 p2=p2;
 free(p3);
 printf("a=%g\n",a);
// WCheckMemCleaningShow();
// WCheckMemCleaning();
return 0;
}

