#pragma once
int WCheckMemCleaningShow(void);
int WCheckMemCleaning(void);
